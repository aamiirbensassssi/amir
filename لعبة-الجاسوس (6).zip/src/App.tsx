/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Users, Timer, Ghost, MapPin, Eye, EyeOff, Play, RotateCcw, Plus, X, AlertTriangle } from 'lucide-react';

const LOCATIONS = [
  'مستشفى', 'مدرسة', 'طائرة', 'غواصة', 'بنك', 'شاطئ', 'سيرك', 
  'كازينو', 'مسرح', 'محطة فضاء', 'سفينة قراصنة', 'مطعم', 
  'مركز شرطة', 'حديقة حيوان', 'محطة قطار', 'فندق', 'متحف', 'قاعدة عسكرية', 'استوديو تصوير'
];

type GameState = 'setup' | 'pass_phone' | 'reveal' | 'playing' | 'result';

export default function App() {
  const [gameState, setGameState] = useState<GameState>('setup');
  const [players, setPlayers] = useState<string[]>(['أحمد', 'محمد', 'علي']);
  const [newPlayerName, setNewPlayerName] = useState('');
  const [spiesCount, setSpiesCount] = useState(1);
  const [timeMinutes, setTimeMinutes] = useState(5);
  
  const [playerRoles, setPlayerRoles] = useState<Record<string, 'spy' | string>>({});
  const [currentLocation, setCurrentLocation] = useState('');
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState(0);
  const [spiesList, setSpiesList] = useState<string[]>([]);
  
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (gameState === 'playing' && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && gameState === 'playing') {
      setGameState('result');
    }
    return () => clearInterval(timer);
  }, [gameState, timeLeft]);

  const addPlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPlayerName.trim() && !players.includes(newPlayerName.trim())) {
      setPlayers([...players, newPlayerName.trim()]);
      setNewPlayerName('');
    }
  };

  const removePlayer = (nameToRemove: string) => {
    setPlayers(players.filter(name => name !== nameToRemove));
  };

  const startGame = () => {
    if (players.length < 3) return;
    
    const location = LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)];
    setCurrentLocation(location);
    
    // Assign roles
    const shuffledPlayers = [...players].sort(() => 0.5 - Math.random());
    const spies = shuffledPlayers.slice(0, spiesCount);
    setSpiesList(spies);
    
    const roles: Record<string, string> = {};
    players.forEach(player => {
      if (spies.includes(player)) {
        roles[player] = 'spy';
      } else {
        roles[player] = location;
      }
    });
    
    setPlayerRoles(roles);
    setCurrentPlayerIndex(0);
    setTimeLeft(timeMinutes * 60);
    setGameState('pass_phone');
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const nextPlayerOrPlay = () => {
    if (currentPlayerIndex < players.length - 1) {
      setCurrentPlayerIndex(prev => prev + 1);
      setGameState('pass_phone');
    } else {
      setGameState('playing');
    }
  };

  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
    exit: { opacity: 0, y: -20, transition: { duration: 0.3 } }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-neutral-950 text-white font-sans flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md relative">
        <AnimatePresence mode="wait">
          
          {/* SETUP SCREEN */}
          {gameState === 'setup' && (
            <motion.div 
              key="setup"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl"
            >
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-500/20 text-red-500 mb-4">
                  <Ghost size={32} />
                </div>
                <h1 className="text-3xl font-black text-white mb-2">لعبة الجاسوس</h1>
                <p className="text-neutral-400 text-sm">اكتشفوا من هو الجاسوس بينكم!</p>
              </div>

              <div className="space-y-6">
                {/* Players List */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-semibold text-neutral-300 mb-2">
                    <Users size={16} /> اللاعبين ({players.length})
                  </label>
                  <form onSubmit={addPlayer} className="flex gap-2 mb-3">
                    <input 
                      type="text" 
                      value={newPlayerName}
                      onChange={(e) => setNewPlayerName(e.target.value)}
                      placeholder="اسم اللاعب..."
                      className="flex-1 bg-neutral-800 border border-neutral-700 rounded-xl px-4 py-2 focus:outline-none focus:border-red-500 transition-colors"
                    />
                    <button type="submit" className="bg-neutral-800 text-white p-2 rounded-xl hover:bg-neutral-700 transition-colors">
                      <Plus size={24} />
                    </button>
                  </form>
                  <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto p-1">
                    {players.map((player) => (
                      <span key={player} className="inline-flex items-center gap-1 bg-neutral-800 px-3 py-1.5 rounded-full text-sm">
                        {player}
                        <button onClick={() => removePlayer(player)} className="text-neutral-500 hover:text-red-400">
                          <X size={14} />
                        </button>
                      </span>
                    ))}
                  </div>
                  {players.length < 3 && (
                    <p className="text-red-400 text-xs mt-2 flex items-center gap-1">
                      <AlertTriangle size={12} /> يجب أن يكون العدد 3 لاعبين على الأقل
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* Spies Count */}
                  <div>
                    <label className="flex items-center gap-2 text-sm font-semibold text-neutral-300 mb-2">
                      <Ghost size={16} /> عدد الجواسيس
                    </label>
                    <div className="flex items-center justify-between bg-neutral-800 rounded-xl p-1">
                      <button 
                        onClick={() => setSpiesCount(Math.max(1, spiesCount - 1))}
                        className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-neutral-700 text-xl font-bold"
                      >-</button>
                      <span className="font-bold text-lg">{spiesCount}</span>
                      <button 
                        onClick={() => setSpiesCount(Math.min(players.length - 2, spiesCount + 1))}
                        className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-neutral-700 text-xl font-bold"
                      >+</button>
                    </div>
                  </div>

                  {/* Time Limit */}
                  <div>
                    <label className="flex items-center gap-2 text-sm font-semibold text-neutral-300 mb-2">
                      <Timer size={16} /> الوقت (دقائق)
                    </label>
                    <div className="flex items-center justify-between bg-neutral-800 rounded-xl p-1">
                      <button 
                        onClick={() => setTimeMinutes(Math.max(1, timeMinutes - 1))}
                        className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-neutral-700 text-xl font-bold"
                      >-</button>
                      <span className="font-bold text-lg">{timeMinutes}</span>
                      <button 
                        onClick={() => setTimeMinutes(Math.min(15, timeMinutes + 1))}
                        className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-neutral-700 text-xl font-bold"
                      >+</button>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={startGame}
                  disabled={players.length < 3}
                  className="w-full bg-red-600 hover:bg-red-500 disabled:bg-neutral-800 disabled:text-neutral-500 text-white font-bold text-lg py-4 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
                >
                  <Play size={20} /> ابدأ اللعبة
                </button>
              </div>
            </motion.div>
          )}

          {/* PASS PHONE SCREEN */}
          {gameState === 'pass_phone' && (
            <motion.div 
              key="pass_phone"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl text-center"
            >
              <div className="text-neutral-400 mb-2 text-sm font-medium tracking-wider">اللاعب التالي</div>
              <h2 className="text-4xl font-black text-white mb-12">{players[currentPlayerIndex]}</h2>
              
              <div className="w-24 h-24 bg-neutral-800 rounded-full mx-auto mb-12 flex items-center justify-center animate-pulse">
                <Ghost size={48} className="text-neutral-500" />
              </div>

              <p className="text-neutral-300 mb-8 font-medium">مرر الهاتف إلى <span className="text-red-400 font-bold">{players[currentPlayerIndex]}</span></p>
              
              <button 
                onClick={() => setGameState('reveal')}
                className="w-full bg-white text-black hover:bg-neutral-200 font-bold text-lg py-4 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                <Eye size={20} /> أنا مستعد، اكشف دوري
              </button>
            </motion.div>
          )}

          {/* REVEAL ROLE SCREEN */}
          {gameState === 'reveal' && (
            <motion.div 
              key="reveal"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl text-center"
            >
              <div className="text-neutral-400 mb-2 text-sm font-medium">دور اللاعب</div>
              <h2 className="text-2xl font-bold text-white mb-12">{players[currentPlayerIndex]}</h2>
              
              {playerRoles[players[currentPlayerIndex]] === 'spy' ? (
                <div className="mb-12">
                  <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-red-500/20 text-red-500 mb-6">
                    <Ghost size={48} />
                  </div>
                  <h3 className="text-3xl font-black text-red-500 mb-2">أنت الجاسوس!</h3>
                  <p className="text-neutral-300">حاول أن لا ينكشف أمرك، وحزر المكان.</p>
                </div>
              ) : (
                <div className="mb-12">
                  <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-blue-500/20 text-blue-400 mb-6">
                    <MapPin size={48} />
                  </div>
                  <h3 className="text-xl font-medium text-neutral-400 mb-2">المكان هو</h3>
                  <p className="text-4xl font-black text-white">{currentLocation}</p>
                </div>
              )}
              
              <button 
                onClick={nextPlayerOrPlay}
                className="w-full bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-lg py-4 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                <EyeOff size={20} /> أخفِ الدور وتابع
              </button>
            </motion.div>
          )}

          {/* PLAYING (TIMER) SCREEN */}
          {gameState === 'playing' && (
            <motion.div 
              key="playing"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl text-center"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-500/20 text-blue-400 mb-6">
                <Timer size={32} />
              </div>
              <h2 className="text-xl font-medium text-neutral-400 mb-2">الوقت المتبقي</h2>
              
              <div className={`text-6xl font-black tabular-nums tracking-tight mb-8 ${timeLeft <= 30 ? 'text-red-500 animate-pulse' : 'text-white'}`}>
                {formatTime(timeLeft)}
              </div>
              
              <p className="text-neutral-400 mb-10 leading-relaxed">
                ابدأوا بطرح الأسئلة على بعضكم البعض لاكتشاف الجاسوس!
              </p>
              
              <button 
                onClick={() => setGameState('result')}
                className="w-full bg-red-600 hover:bg-red-500 text-white font-bold text-lg py-4 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                إنهاء المناقشة والتصويت
              </button>
            </motion.div>
          )}

          {/* RESULT SCREEN */}
          {gameState === 'result' && (
            <motion.div 
              key="result"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="bg-neutral-900 border border-neutral-800 rounded-3xl p-8 shadow-2xl text-center"
            >
              <div className="mb-10">
                <h2 className="text-xl font-medium text-neutral-400 mb-2">المكان كان</h2>
                <div className="flex items-center justify-center gap-2 text-3xl font-black text-white">
                  <MapPin className="text-blue-400" /> {currentLocation}
                </div>
              </div>

              <div className="w-full h-px bg-neutral-800 mb-10"></div>

              <div className="mb-12">
                <h2 className="text-xl font-medium text-neutral-400 mb-4">{spiesList.length > 1 ? 'الجواسيس هم' : 'الجاسوس كان'}</h2>
                <div className="flex flex-col gap-3 items-center">
                  {spiesList.map(spy => (
                    <div key={spy} className="flex items-center gap-3 bg-red-500/10 border border-red-500/20 text-red-400 px-6 py-3 rounded-2xl w-full justify-center">
                      <Ghost size={24} />
                      <span className="text-2xl font-bold">{spy}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <button 
                onClick={() => setGameState('setup')}
                className="w-full bg-white text-black hover:bg-neutral-200 font-bold text-lg py-4 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                <RotateCcw size={20} /> العب مرة أخرى
              </button>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  );
}
